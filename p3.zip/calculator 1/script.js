let expression = "";
const inputField = document.querySelector('input');
const buttons = document.querySelectorAll('.button');

buttons.forEach(button => {
  button.addEventListener('click', () => {
    const value = button.textContent;

    if (value === '=') {
      try {
        expression = eval(expression);
      } catch {
        expression = 'Error';
      }
    } else if (value === 'C') {
      expression = "";
    } else {
      expression += value;
    }
    
    inputField.value = expression;
  });
});
