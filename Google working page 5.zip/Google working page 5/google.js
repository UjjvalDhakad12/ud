document.getElementById("searchButton").addEventListener("click", function() {

    let query = document.getElementById("name").value;
    

    if (query.trim() !== "") {
    
        window.location.href = "https://www.google.com/search?q=" + encodeURIComponent(query);
    } else {
        alert("Please enter a search query!");
    }
});